﻿ASAP - Another Slight Atari Player
==================================

ASAP is a player of Atari 8-bit chiptunes for modern computers and mobile
devices.  It emulates the POKEY sound chip and the 6502 processor.

ASAP supports the following file formats: SAP, CMC, CM3, CMR, CMS, DMC, DLT,
FC, MPT, MPD, MD1+D15, MD1+D8, MD2+D8, RMT, TMC/TM8, TM2, STIL
and is available on Android, Windows, macOS, Linux and modern web browsers.

ASAP is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published
by the Free Software Foundation; either version 2 of the License,
or (at your option) any later version.

See the INSTALL file for build instructions.

For more information, visit the website: https://asap.sourceforge.net/
