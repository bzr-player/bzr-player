
ENABLE_TESTING()
include ( FluidUnitTest )

# first define the test target, used by the macros below
if( NOT ANDROID )
    add_custom_target(check COMMAND ${CMAKE_CTEST_COMMAND} -C $<CONFIG>  --output-on-failure)
else()
    # skip ctest on android, execution must be done via android emulator
    add_custom_target(check)
endif()

# stage the unit test data files (see TEST_DATA_FILES in the top-level
# CMakeLists.txt) into ${CMAKE_BINARY_DIR}/test so the tests can access them
# via relative paths
add_dependencies(check test_data)


## add unit tests here ##
ADD_FLUID_TEST(test_synth_reset_cc)
ADD_FLUID_TEST(test_bank_select_gm2)
ADD_FLUID_TEST(test_sample_cache)
ADD_FLUID_TEST(test_sfont_loading)
#ADD_FLUID_TEST(test_sample_rate_change)
ADD_FLUID_TEST(test_preset_sample_loading)
ADD_FLUID_TEST(test_preset_pinning)
ADD_FLUID_TEST(test_bug_635)
ADD_FLUID_TEST(test_settings_unregister_callback)
ADD_FLUID_TEST(test_pointer_alignment)
ADD_FLUID_TEST(test_seqbind_unregister)
ADD_FLUID_TEST(test_synth_chorus_reverb)
ADD_FLUID_TEST(test_snprintf)
ADD_FLUID_TEST(test_synth_process)
ADD_FLUID_TEST(test_ct2hz)
ADD_FLUID_TEST(test_lfo)
ADD_FLUID_TEST(test_sample_validate)
ADD_FLUID_TEST(test_sfont_unloading)
ADD_FLUID_TEST(test_sfont_zone)
ADD_FLUID_TEST(test_seq_event_queue_sort)
ADD_FLUID_TEST(test_seq_scale)
ADD_FLUID_TEST(test_seq_evt_order)
ADD_FLUID_TEST(test_midi_parser_realtime)
ADD_FLUID_TEST(test_midi_router)
ADD_FLUID_TEST(test_midi_file_tempo)
ADD_FLUID_TEST(test_seq_event_queue_remove)
ADD_FLUID_TEST(test_jack_obtaining_synth)
ADD_FLUID_TEST(test_utf8_open)
ADD_FLUID_TEST(test_portamento_time)
ADD_FLUID_TEST(test_modulator)
ADD_FLUID_TEST(test_default_mod)
ADD_FLUID_TEST(test_synth_render_s16)
ADD_FLUID_TEST(test_synth_render_s24)
ADD_FLUID_TEST(test_synth_render_s32)
ADD_FLUID_TEST(test_round_clip)
ADD_FLUID_TEST(test_ABI)
ADD_FLUID_TEST(test_file_seek_tell)
ADD_FLUID_TEST(test_shell_server_auto_port)
ADD_FLUID_TEST(test_shell_parse_argv_internal)
ADD_FLUID_TEST(test_sample_pitch_calculation)
ADD_FLUID_TEST(test_mts_cc_tuning)
ADD_FLUID_TEST(test_voice_callback)
ADD_FLUID_TEST(test_voice_reuse_gain)
ADD_FLUID_TEST(test_basic_channel)
ADD_FLUID_TEST(test_rvoice_mixer LINK_AS_ARCHIVE)
ADD_FLUID_TEST(test_rvoice_dsp_interpolate)
ADD_FLUID_TEST(test_iir_coefficient_reuse)

if ( NOT OSAL STREQUAL "embedded" )
    ADD_FLUID_TEST(test_threading)
endif ( NOT OSAL STREQUAL "embedded" )

if ( ENABLE_MIXER_THREADS AND NOT osal STREQUAL "embedded" )
    ADD_FLUID_TEST(test_rvoice_mixer_worker_startup LINK_AS_ARCHIVE)
    ADD_FLUID_TEST(test_rvoice_mixer_threads)
endif()

if( LIBSNDFILE_SUPPORT )
    ADD_FLUID_TEST(test_fast_render)
endif()

ADD_FLUID_TEST_UTIL(dump_sfont)

ADD_FLUID_SF_DUMP_TEST(VintageDreamsWaves-v2.sf2)

if ( LIBSNDFILE_HASVORBIS )
    ADD_FLUID_TEST(test_sf3_sfont_loading)
    ADD_FLUID_TEST(test_sf3_gain)
    ADD_FLUID_SF_DUMP_TEST(VintageDreamsWaves-v2.sf3)
endif ( LIBSNDFILE_HASVORBIS )

if(NOT CMAKE_GENERATOR MATCHES "Visual Studio")

    # Prepare the manual test suite down here
    if(NOT DEFINED GENERAL_USER_GS2)
        set ( GENERAL_USER_GS2 "${CMAKE_CURRENT_SOURCE_DIR}/manual/sf2/GeneralUser-GS/GeneralUser-GS.sf2" )
    endif()

    if (NOT RENDERING_OUTPUT_DIR)
        set(RENDERING_OUTPUT_DIR "${CMAKE_CURRENT_BINARY_DIR}/manual")
    endif()

    set(IIR_FILTER_RENDER_DIR "${RENDERING_OUTPUT_DIR}/iir_filter")
    set(AWE32_NRPN_RENDER_DIR "${RENDERING_OUTPUT_DIR}/awe32_nrpn")
    set(SF2_NRPN_RENDER_DIR "${RENDERING_OUTPUT_DIR}/sf2_nrpn")
    set(SFSPEC_RENDER_DIR "${RENDERING_OUTPUT_DIR}/SoundFont-Spec-Test")
    set(GUGDEMO_RENDER_DIR "${RENDERING_OUTPUT_DIR}/sf2/GeneralUser-GS")
    set(PORTAMENTO_RENDER_DIR "${RENDERING_OUTPUT_DIR}/portamento")
    set(REVERB_RENDER_DIR "${RENDERING_OUTPUT_DIR}/reverb")
    set(EXCL_RENDER_DIR "${RENDERING_OUTPUT_DIR}/exclusive_class")
    set(DSPINTERP_RENDER_DIR "${RENDERING_OUTPUT_DIR}/dsp_interp")
    set(DYNSAM_RENDER_DIR "${RENDERING_OUTPUT_DIR}/dynamic-sample-loading")
    set(BANKSELECT_RENDER_DIR "${RENDERING_OUTPUT_DIR}/midi-bank-select")
    set(STACKEDSF_RENDER_DIR "${RENDERING_OUTPUT_DIR}/stacked_sf2")
    set(SFE_RENDER_DIR "${RENDERING_OUTPUT_DIR}/sfe")
    set(RPN_RENDER_DIR "${RENDERING_OUTPUT_DIR}/rpn")
    set(SYSEX_GS_DT1 "${RENDERING_OUTPUT_DIR}/sysex/gs_dt1")
    set(LIMITER_RENDER_DIR "${RENDERING_OUTPUT_DIR}/limiter")
    set(MTS_RENDER_DIR "${RENDERING_OUTPUT_DIR}/mts")
    set(MISC_RENDER_DIR "${RENDERING_OUTPUT_DIR}/misc")

    if(LIBSNDFILE_SUPPORT)
        set(FEXT "wav")
    else()
        set(FEXT "raw")
    endif()

    set(MANUAL_TEST_FLUIDSYNTH "" CACHE FILEPATH "FluidSynth executable for manual regression tests")
    if (MANUAL_TEST_FLUIDSYNTH)
        set(MANUAL_TEST_DEPENDS "")
    else()
        set(MANUAL_TEST_FLUIDSYNTH "$<TARGET_FILE:fluidsynth>")
        set(MANUAL_TEST_DEPENDS fluidsynth)
    endif()

    # Add an empty pseudo target
    add_custom_target(check_rendering)
    add_custom_target(check_manual)

    add_custom_target(create_out_dir
        COMMAND ${CMAKE_COMMAND} -E make_directory ${IIR_FILTER_RENDER_DIR} ${AWE32_NRPN_RENDER_DIR} ${SFSPEC_RENDER_DIR} ${PORTAMENTO_RENDER_DIR} ${REVERB_RENDER_DIR} ${EXCL_RENDER_DIR} ${DSPINTERP_RENDER_DIR} ${DYNSAM_RENDER_DIR} ${STACKEDSF_RENDER_DIR} ${GUGDEMO_RENDER_DIR} ${BANKSELECT_RENDER_DIR} ${SFE_RENDER_DIR} ${SYSEX_GS_DT1} ${RPN_RENDER_DIR} ${LIMITER_RENDER_DIR} ${MTS_RENDER_DIR} ${MISC_RENDER_DIR}
        VERBATIM)

    add_custom_target(render1415
        COMMAND ${MANUAL_TEST_FLUIDSYNTH} -R 0 -C 0 -g 1 -F ${IIR_FILTER_RENDER_DIR}/1415_the-nervous-filter.${FEXT} "The Nervous Filter trimmed.mid" ${GENERAL_USER_GS2}
        COMMENT "Rendering testfile of issue 1415"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
        WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/manual/iir_filter/1415_the-nervous-filter/
        VERBATIM
    )

    add_custom_target(render1417
        COMMAND ${MANUAL_TEST_FLUIDSYNTH} -R 0 -C 0 -g 1 -F ${IIR_FILTER_RENDER_DIR}/1417_filter-envelope-noise.${FEXT} filter-envelope-noise.mid ${GENERAL_USER_GS2}
        COMMENT "Rendering testfile of issue 1417"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
        WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/manual/iir_filter/1417_filter-envelope-noise/
        VERBATIM
    )

    add_custom_target(render1424
        COMMAND ${MANUAL_TEST_FLUIDSYNTH} -R 0 -C 0 -g 1 -F ${IIR_FILTER_RENDER_DIR}/1424_clicks-on-ModEnv-FilterFc-change.${FEXT} 1424.mid echo_drops.sf2
        COMMENT "Rendering testfile of issue 1424"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
        WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/manual/iir_filter/1424_clicks-on-ModEnv-FilterFc-change/
        VERBATIM
    )

    add_custom_target(render1427
        COMMAND ${MANUAL_TEST_FLUIDSYNTH} -R 0 -C 0 -g 5 -F ${IIR_FILTER_RENDER_DIR}/1427_high-Q-note-cutoff.${FEXT} high_Q_note_cutoff_test.mid high_Q_note_cutoff_test.sf2
        COMMENT "Rendering testfile of issue 1427"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
        WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/manual/iir_filter/1427_high-Q-note-cutoff/
        VERBATIM
    )

    add_custom_target(renderRealtimeIIR
        COMMAND ${MANUAL_TEST_FLUIDSYNTH} -R 0 -C 0 -g 0.5 -niq "high poly audio breakup.mid" "high poly preset test.sf2" # -F "${IIR_FILTER_RENDER_DIR}/1481 high poly audio breakup.${FEXT}"
        COMMENT "Realtime-Rendering testfile of issue 1481"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
        WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/manual/iir_filter/1481_realtime-playback/
        VERBATIM
    )

    add_custom_target(render1481
        COMMAND ${MANUAL_TEST_FLUIDSYNTH} -R 0 -C 0 -g 1.8 -F ${IIR_FILTER_RENDER_DIR}/1481_cutoff-resolution.${FEXT} "filter resolution test.mid" "filter resolution test.sf2"
        COMMENT "Rendering testfile of issue 1481"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
        WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/manual/iir_filter/1481_cutoff-resolution/
        VERBATIM
    )

    add_custom_target(renderAltitude
        COMMAND ${MANUAL_TEST_FLUIDSYNTH} -R 1 -C 1 -g 0.5 -f fluidsynth.cfg -F ${AWE32_NRPN_RENDER_DIR}/Altitude.${FEXT} ../../sf2/synthgs-sf2_04-compat.sf2 -b 1 Altitude.sf2 Altitude.mid
        COMMENT "Rendering AWE32 NRPN test file Altitude.mid"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
        WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/manual/awe32_nrpn/Altitude/
        VERBATIM
    )

    add_custom_target(renderFilter
        COMMENT "Rendering AWE32 NRPN test file The Nervous Filter.mid"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderFilter PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/awe32_nrpn/Filter/"
    )

    set(_filter_soundfonts
        ${GENERAL_USER_GS2}
        "1mgm.sf2"
        "GM_Roland.sf2"
    )
    foreach(_sf IN LISTS _filter_soundfonts)
        get_filename_component(_sf_basename ${_sf} NAME_WE)
        add_render_job(renderFilter
            "${AWE32_NRPN_RENDER_DIR}/The Nervous Filter ${_sf_basename}.${FEXT}"
            -R 0 -C 0 -g 0.5 "The Nervous Filter.mid" "${_sf}"
        )
    endforeach()

    add_custom_target(renderUplift
        COMMAND ${MANUAL_TEST_FLUIDSYNTH} -R 1 -C 0 -g 0.7 -f fluidsynth.cfg -F ${AWE32_NRPN_RENDER_DIR}/Uplift-fixed.${FEXT} ../../sf2/synthgs-sf2_04-compat.sf2 -b 1 Uplift.sf2 Uplift-fixed.mid
        COMMENT "Rendering AWE32 NRPN test file Uplift.mid"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
        WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/manual/awe32_nrpn/Uplift/
        VERBATIM
    )

    add_custom_target(renderChrisNRPN
        COMMAND ${MANUAL_TEST_FLUIDSYNTH} -R 0 -C 0 -g 1.8 -F ${AWE32_NRPN_RENDER_DIR}/filter_NRPN_test.${FEXT} "filter_NRPN_test.mid" "filter_NRPN_test.sf2"
        COMMENT "Rendering Chris' AWE32 NRPN filter test file"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/SoundFont-Spec-Test/NRPN test - filter/"
    )

    add_custom_target(renderHybridCol
        COMMENT "Rendering Christian's HYBRID Collage"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderHybridCol PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/awe32_nrpn/HYBRID.Collage/"
    )
    add_render_job(renderHybridCol
        "${AWE32_NRPN_RENDER_DIR}/HYBRID Collage NRPN.${FEXT}"
        -R 1 -C 1 -g 0.7 "HYBRID Collage NRPN.mid" ${GENERAL_USER_GS2}
    )
    add_render_job(renderHybridCol
        "${AWE32_NRPN_RENDER_DIR}/HYBRID Collage wah-guitar.${FEXT}"
        -R 1 -C 1 -g 0.7 "HYBRID Collage wah-guitar.mid" ${GENERAL_USER_GS2}
    )

    add_custom_target(renderPortamento
        COMMENT "Rendering Portamento tests"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderPortamento PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/portamento/"
    )
    add_render_job(renderPortamento
        "${PORTAMENTO_RENDER_DIR}/1TOWOW_reduced_to_A3_C4.${FEXT}"
        -R 0 -C 0 -g 0.6 "1TOWOW_reduced_to_A3_C4.mid" ${GENERAL_USER_GS2}
    )
    add_render_job(renderPortamento
        "${PORTAMENTO_RENDER_DIR}/1TOWOW_reduced_to_A3_C4_linear.${FEXT}"
        -o "synth.portamento-time=linear" -R 0 -C 0 -g 0.6 "1TOWOW_reduced_to_A3_C4.mid" ${GENERAL_USER_GS2}
    )
    add_render_job(renderPortamento
        "${PORTAMENTO_RENDER_DIR}/1TOWOW.${FEXT}"
        -R 0 -C 0 -g 0.7 "1TOWOW.MID" ${GENERAL_USER_GS2}
    )
    add_render_job(renderPortamento
        "${PORTAMENTO_RENDER_DIR}/3 - Turn Up, Strut In, Chill Out (XG).${FEXT}"
        -R 0 -C 0 -g 0.7 "3 - Turn Up, Strut In, Chill Out (XG).mid" ${GENERAL_USER_GS2}
    )
    add_render_job(renderPortamento
        "${PORTAMENTO_RENDER_DIR}/6 - Galactic Invasion (XG).${FEXT}"
        -R 0 -C 0 -g 0.7 "6 - Galactic Invasion (XG).mid" ${GENERAL_USER_GS2}
    )
    add_render_job(renderPortamento
        "${PORTAMENTO_RENDER_DIR}/Descent_Game08.${FEXT}"
        -R 0 -C 0 -g 0.5 "Descent_Game08.mid" ${GENERAL_USER_GS2}
    )
    add_render_job(renderPortamento
        "${PORTAMENTO_RENDER_DIR}/Descent_Game08_linear.${FEXT}"
        -o "synth.portamento-time=linear" -R 0 -C 0 -g 0.5 "Descent_Game08.mid" ${GENERAL_USER_GS2}
    )
    add_render_job(renderPortamento
        "${PORTAMENTO_RENDER_DIR}/MM6_-_MrX2010XG.${FEXT}"
        -R 0 -C 0 -g 0.6 "MM6_-_MrX2010XG.mid" ${GENERAL_USER_GS2}
    )


    add_custom_target(renderSfSpecTest
        COMMAND ${MANUAL_TEST_FLUIDSYNTH} -R 1 -C 1 -g 0.5 -F ${SFSPEC_RENDER_DIR}/sf_spec_test.${FEXT} sf_spec_test.mid sf_spec_test.sf2
        COMMENT "Rendering Christian Collins' SF2 spec test"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
        WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/manual/SoundFont-Spec-Test/
        VERBATIM
    )

    set(_1455_rev_width
        "0.0"
        "0.5"
        "1.0"
        "5.0"
        "10.0"
        "50.0"
        "100.0"
    )
    add_custom_target(render1455
        COMMENT "Rendering Christian Collins' reverb test issue 1455"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(render1455 PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/reverb/"
    )
    foreach(_w IN LISTS _1455_rev_width)
        add_render_job(render1455
            "${REVERB_RENDER_DIR}/mrbumpys_rev_width_test_${_w}.${FEXT}"
            -R 1 -C 0 -g 0.5 -o "synth.reverb.width=${_w}" "mrbumpys_rev_width_test.mid" ${GENERAL_USER_GS2}
        )
    endforeach()

    add_custom_target(render1496
        COMMAND ${MANUAL_TEST_FLUIDSYNTH} -R 1 -C 0 -g 0.5 -o synth.reverb.width=0.0 -F ${REVERB_RENDER_DIR}/1496.${FEXT} mrbumpys_rev_width_test.mid 1496.sf2
        COMMENT "Rendering reverb test issue 1496"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
        WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/manual/reverb/
        VERBATIM
    )

    set(DK64SF2 "../sf2/ANMP-data/soundfonts/N64/DK64.sf2")
    add_custom_target(renderDK64JJU
        COMMENT "Praise Grant Kirkhope!"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderDK64JJU PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/reverb/"
    )
    foreach(_w IN LISTS _1455_rev_width)
        add_render_job(renderDK64JJU
            "${REVERB_RENDER_DIR}/DK64_sparse04_${_w}.${FEXT}"
            -R 1 -C 0 -g 0.5 -o "synth.reverb.width=${_w}" DK64_sparse04.mid ${DK64SF2}
        )
    endforeach()


    set(_note_cut
        "0"
        "1"
        "2"
    )
    add_custom_target(renderExcl
        COMMENT "Rendering exclusive class cutoff tests"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderExcl PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/exclusive_class/"
    )

    foreach(_n IN LISTS _note_cut)
        add_render_job(renderExcl
            "${EXCL_RENDER_DIR}/MIDInotecut${_n}.${FEXT}"
            -R 0 -C 0 -g 1.4 -o "synth.note-cut=${_n}" "MIDInotecut.mid" ${GENERAL_USER_GS2}
        )
    endforeach()
    add_render_job(renderExcl
        "${EXCL_RENDER_DIR}/exclusive class cutoff speed.${FEXT}"
        -R 0 -C 0 -g 1.4 "exclusive class cutoff speed.mid" "exclusive class cutoff speed.sf2"
    )
    add_render_job(renderExcl
        "${EXCL_RENDER_DIR}/percussion note cutoff.${FEXT}"
        -R 0 -C 0 -g 1.4  "percussion note cutoff.mid" ${GENERAL_USER_GS2}
    )
    add_render_job(renderExcl
        "${EXCL_RENDER_DIR}/percussion-test.${FEXT}"
        -R 0 -C 0 -g 1.4 "percussion-test.mid" ${GENERAL_USER_GS2}
    )


    add_custom_target(rendere1m1
        COMMENT "Rendering Doom E1M1 with note-cut 0,1,2"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(rendere1m1 PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/exclusive_class/"
    )
    foreach(_n IN LISTS _note_cut)
        add_render_job(rendere1m1
            "${EXCL_RENDER_DIR}/e1m1_GeneralUser2_notecut${_n}.${FEXT}"
            -R 0 -C 0 -g 0.6 -o "synth.note-cut=${_n}" "e1m1.mid" ${GENERAL_USER_GS2}
        )
        add_render_job(rendere1m1
            "${EXCL_RENDER_DIR}/e1m1_gzdoom_notecut${_n}.${FEXT}"
            -R 0 -C 0 -g 0.6 -o "synth.note-cut=${_n}" "e1m1.mid" "../sf2/gzdoom.sf2"
        )
    endforeach()

    add_custom_target(renderdspInterp
        COMMENT "Rendering Interpolation examples"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderdspInterp PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/SoundFont-Spec-Test/sample interpolation test/"
    )

    set(_interp
        "interp0"
        "interp1"
        "interp4"
        "interp5"
        "interp6"
        "interp7"
    )
    foreach(_i IN LISTS _interp)
        add_render_job(renderdspInterp
            "${DSPINTERP_RENDER_DIR}/sample_interpolation_test_${_i}.flac"
            -f "../../config/${_i}.cfg" -R 0 -C 0 -g 0.6 -o audio.file.format=s24 -o audio.file.type=flac -r 48000 "sample interpolation test.mid" "sample interpolation test.sf2"
        )
    endforeach()

    add_custom_target(render1484
        COMMENT "Rendering dynamic sample loading test"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(render1484 PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/dynamic-sample-loading/"
    )
    add_render_job(render1484
        "${DYNSAM_RENDER_DIR}/DrTebz_dynamic-sample-loading_on.${FEXT}"
        -R 0 -C 0 -g 0.6 -o synth.dynamic-sample-loading=1 "dynamic-sample-loading_test.mid" "DrTebz.sf2"
    )
    add_render_job(render1484
        "${DYNSAM_RENDER_DIR}/DrTebz_dynamic-sample-loading_off.${FEXT}"
        -R 0 -C 0 -g 0.6 -o synth.dynamic-sample-loading=0 "dynamic-sample-loading_test.mid" "DrTebz.sf2"
    )

    add_custom_target(render1505
        COMMENT "Rendering dynamic sample loading test"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(render1505 PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/dynamic-sample-loading/"
    )
    add_render_job(render1505
        "${DYNSAM_RENDER_DIR}/ran_dynamic-sample-loading_on.${FEXT}"
        -R 0 -C 0 -g 0.6 -o synth.dynamic-sample-loading=1 ${GENERAL_USER_GS2} "ran.dls" "ran.mid"
    )
    add_render_job(render1505
        "${DYNSAM_RENDER_DIR}/ran_dynamic-sample-loading_off.${FEXT}"
        -R 0 -C 0 -g 0.6 -o synth.dynamic-sample-loading=0 ${GENERAL_USER_GS2} "ran.dls" "ran.mid"
    )

    set(_gs_demos
        "Bond"
        "Breakout"
        "Dance"
        "Earth Day - by Richard Audd (fixed)"
        "J-cycle"
        "Jump!"
        "Santa Claus is Comin' to Town"
        "The HYBRID Collage (v2.0) - by S. Christian Collins"
        "Umi no Mieru Machi"
    )
    add_custom_target(renderGeneralUserDemo
        COMMENT "Rendering General User MIDI Demos"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderGeneralUserDemo PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/sf2/GeneralUser-GS/demo MIDIs/"
    )
    foreach(_demo IN LISTS _gs_demos)
        add_render_job(renderGeneralUserDemo
            "${GUGDEMO_RENDER_DIR}/${_demo}.${FEXT}"
            -R 0 -C 0 -g 0.6 "${_demo}.mid" ${GENERAL_USER_GS2}
        )
    endforeach()

    set(_bankselect_demos
        "Dance_GM"
        "Dance_GM2"
        "Dance_GS"
        "Dance_original"
        "Dance_XG"
    )
    add_custom_target(renderBankSelect
        COMMENT "Rendering MIDI Bank selection tests"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderBankSelect PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/midi-bank-select"
    )
    foreach(_demo IN LISTS _bankselect_demos)
        add_render_job(renderBankSelect
            "${BANKSELECT_RENDER_DIR}/${_demo}.${FEXT}"
            -R 0 -C 0 -g 0.6 "${_demo}.mid" ${GENERAL_USER_GS2}
        )
    endforeach()
    add_render_job(renderBankSelect
        "${BANKSELECT_RENDER_DIR}/9 - On 'Til Morning.${FEXT}"
        -o "synth.midi-bank-select=xg" -g 0.6 ${GENERAL_USER_GS2} "issue-1524/9 - On 'Til Morning.mid"
    )
    add_render_job(renderBankSelect
        "${BANKSELECT_RENDER_DIR}/MM6_-_MrX2010XG.${FEXT}"
        -g 0.6 "issue-1524/Default.sf2" "issue-1524/MM6_-_MrX2010XG.mid"
    )

    add_custom_target(renderDMOD
        COMMAND ${MANUAL_TEST_FLUIDSYNTH} -R 0 -C 0 -g 0.2 -F "${SFE_RENDER_DIR}/DMOD.${FEXT}" DMOD.sf2 "test-rpn-00-00-pitch-bend-range.mid"
        COMMENT "Rendering Test MIDI for DMOD SF2"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/sfe/dmod"
        VERBATIM
    )

    add_custom_target(renderRPN
        COMMENT "Rendering Test MIDI for RPNs"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderRPN PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/rpn"
    )
    add_render_job(renderRPN
        "${RPN_RENDER_DIR}/SA2 - Prison Lane -- MIDIMan - FluidSynth Test.${FEXT}"
        -R 0 -C 0 -g 1.1 ${GENERAL_USER_GS2} "FluidSynth.pitch.bend.fine.tuning.bug.demonstration/SA2 - Prison Lane -- MIDIMan - FluidSynth Test.mid"
    )
    add_render_job(renderRPN
        "${RPN_RENDER_DIR}/modulation-range/test-rpn-00-05-modulation-depth-range.${FEXT}"
        -R 0 -C 0 -g 1.9 ${GENERAL_USER_GS2} "modulation-range/test-rpn-00-05-modulation-depth-range.mid"
    )
    add_render_job(renderRPN
        "${RPN_RENDER_DIR}/modulation-range/mod-rpn-no-mod-wheel.${FEXT}"
        -R 0 -C 0 -g 1.4 modulation-range/vib.sf2 "modulation-range/mod-rpn-no-mod-wheel.mid"
    )

    set(_gsdt1_demos
        "wikipedia_MIDI_sample_gstest"
        "D_DM2TTL - GS Drums"
        "GS Drums Bank Select and Program Change interaction on MSGS"
    )
    add_custom_target(renderGSDT1
        COMMENT "Rendering Test MIDIs for SysEx GS DT1"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderGSDT1 PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/sysex/gs_dt1"
    )
    foreach(_demo IN LISTS _gsdt1_demos)
        add_render_job(renderGSDT1
            "${SYSEX_GS_DT1}/${_demo}.${FEXT}"
            -R 0 -C 0 -g 0.6 "${_demo}.mid" ${GENERAL_USER_GS2}
        )
    endforeach()

    add_custom_target(renderLimiterTests
        COMMENT "Rendering Limiter Tests"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderLimiterTests PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/awe32_nrpn/Uplift/"
    )
    add_render_job(renderLimiterTests
        "${LIMITER_RENDER_DIR}/Uplift-limiter_default.${FEXT}"
        -o synth.limiter.active=1 -R 1 -C 0 -g 0.7 -f fluidsynth.cfg ../../sf2/synthgs-sf2_04-compat.sf2 -b 1 Uplift.sf2 Uplift-fixed.mid
    )
    add_render_job(renderLimiterTests
        "${LIMITER_RENDER_DIR}/Uplift-limiter_a1.${FEXT}"
         -o synth.limiter.active=1 -o synth.limiter.attack=1 -R 1 -C 0 -g 0.7 -f fluidsynth.cfg ../../sf2/synthgs-sf2_04-compat.sf2 -b 1 Uplift.sf2 Uplift-fixed.mid
    )
    add_render_job(renderLimiterTests
        "${LIMITER_RENDER_DIR}/Uplift-limiter_a50.${FEXT}"
        -o synth.limiter.active=1 -o synth.limiter.attack=50 -R 1 -C 0 -g 0.7 -f fluidsynth.cfg ../../sf2/synthgs-sf2_04-compat.sf2 -b 1 Uplift.sf2 Uplift-fixed.mid
    )
    add_render_job(renderLimiterTests
        "${LIMITER_RENDER_DIR}/Uplift-limiter_r0.${FEXT}"
        -o synth.limiter.active=1 -o synth.limiter.release=0 -R 1 -C 0 -g 0.7 -f fluidsynth.cfg ../../sf2/synthgs-sf2_04-compat.sf2 -b 1 Uplift.sf2 Uplift-fixed.mid
    )
    add_render_job(renderLimiterTests
        "${LIMITER_RENDER_DIR}/Uplift-limiter_a1_r0.${FEXT}"
        -o synth.limiter.active=1 -o synth.limiter.attack=1 -o synth.limiter.release=0 -R 1 -C 0 -g 0.7 -f fluidsynth.cfg ../../sf2/synthgs-sf2_04-compat.sf2 -b 1 Uplift.sf2 Uplift-fixed.mid
    )
    add_render_job(renderLimiterTests
        "${LIMITER_RENDER_DIR}/Uplift-limiter_a1_r250.${FEXT}"
        -o synth.limiter.active=1 -o synth.limiter.attack=1 -o synth.limiter.release=250 -R 1 -C 0 -g 0.7 -f fluidsynth.cfg ../../sf2/synthgs-sf2_04-compat.sf2 -b 1 Uplift.sf2 Uplift-fixed.mid
    )
    add_render_job(renderLimiterTests
        "${LIMITER_RENDER_DIR}/Uplift-limiter_lim06.${FEXT}"
        -o synth.limiter.active=1 -o synth.limiter.output-limit=0.6 -R 1 -C 0 -g 0.7 -f fluidsynth.cfg ../../sf2/synthgs-sf2_04-compat.sf2 -b 1 Uplift.sf2 Uplift-fixed.mid
    )
    add_render_job(renderLimiterTests
        "${LIMITER_RENDER_DIR}/Uplift-limiter_h0_lim06.${FEXT}"
        -o synth.limiter.active=1 -o synth.limiter.output-limit=0.6 -o synth.limiter.hold=0 -R 1 -C 0 -g 0.7 -f fluidsynth.cfg ../../sf2/synthgs-sf2_04-compat.sf2 -b 1 Uplift.sf2 Uplift-fixed.mid
    )

if ( ENABLE_NATIVE_DLS )
        add_custom_target(renderStreetwise
            COMMAND ${MANUAL_TEST_FLUIDSYNTH} -R 0 -C 0 -g 0.6 -F "${STACKEDSF_RENDER_DIR}/Streetwise.${FEXT}" "Streetwise.mid" ${GENERAL_USER_GS2} "Streetwise.dls"
            COMMENT "Rendering testcase for stacked soundfonts"
            DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
            WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/manual/stacked_sf2/Streetwise/
            VERBATIM
        )
else ( ENABLE_NATIVE_DLS )
        add_custom_target(renderStreetwise
            COMMAND ${CMAKE_COMMAND} -E cmake_echo_color --red "Cannot render Streetwise, no DLS support!"
            COMMENT "Rendering testcase for stacked soundfonts"
        )
endif (ENABLE_NATIVE_DLS )


    set(_reverb_type
      "fdn"
      "free"
      "lex"
      "dat"
      "smith"
    )

    set(_reverb_width
      "0.0"
      "1.0"
      "10"
    )

    set(_reverb_damp
      "0.0"
      "0.2"
      "0.3"
      "0.7"
      "1"
    )

    set(_reverb_level
      "0.7"
      "1"
    )

    set(_reverb_size
      "0.3"
      "0.5"
      "0.7"
      "1"
    )

    add_custom_target(renderReverbOverview
      COMMENT "Reverb overview study"
      DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderReverbOverview PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/reverb/"
    )

    add_render_job(renderReverbOverview
        "${REVERB_RENDER_DIR}/reverb_water_triangle_test_dry.oga"
        -R 0 -C 0 -g 1.9 reverb_water_triangle_test.mid ${DK64SF2}
    )
    add_render_job(renderReverbOverview
        "${REVERB_RENDER_DIR}/1496_dry.oga"
        -R 0 -C 0 -g 0.4 mrbumpys_rev_width_test.mid 1496.sf2
    )
    add_render_job(renderReverbOverview
        "${REVERB_RENDER_DIR}/1455_dry.oga"
        -R 0 -C 0 -g 0.7 mrbumpys_rev_width_test.mid ${GENERAL_USER_GS2}
    )

    foreach(_t IN LISTS _reverb_type)
        add_render_job(renderReverbOverview
            "${REVERB_RENDER_DIR}/1496_t${_t}.oga"
            -R ${_t} -C 0 -g 0.4 -o synth.reverb.room-size=0.7 -o synth.reverb.width=1 -o synth.reverb.damp=0 -o synth.reverb.level=0.7 mrbumpys_rev_width_test.mid 1496.sf2
        )
        add_render_job(renderReverbOverview
            "${REVERB_RENDER_DIR}/1455_t${_t}.oga"
            -R ${_t} -C 0 -g 0.7 -o synth.reverb.room-size=0.7 -o synth.reverb.width=1 -o synth.reverb.damp=0 -o synth.reverb.level=0.7 mrbumpys_rev_width_test.mid ${GENERAL_USER_GS2}
        )
    endforeach()

    foreach(_l IN LISTS _reverb_level)
    foreach(_s IN LISTS _reverb_size)
    foreach(_w IN LISTS _reverb_width)
    foreach(_d IN LISTS _reverb_damp)
    foreach(_t IN LISTS _reverb_type)
        add_render_job(renderReverbOverview
            "${REVERB_RENDER_DIR}/reverb_water_triangle_test_l${_l}_s${_s}_w${_w}_d${_d}_t${_t}.oga"
             -R ${_t} -C 0 -g 1.9 -o synth.reverb.room-size=${_s} -o synth.reverb.width=${_w} -o synth.reverb.damp=${_d} -o synth.reverb.level=${_l} reverb_water_triangle_test.mid ${DK64SF2}
        )
        add_render_job(renderReverbOverview
            "${REVERB_RENDER_DIR}/DK64_sparse04_l${_l}_s${_s}_w${_w}_d${_d}_t${_t}.oga"
            -R ${_t} -C 0 -g 0.5 -o synth.reverb.room-size=${_s} -o synth.reverb.width=${_w} -o synth.reverb.damp=${_d} -o synth.reverb.level=${_l} DK64_sparse04.mid ${DK64SF2}
        )
    endforeach()
    endforeach()
    endforeach()
    endforeach()
    endforeach()



    add_custom_target(renderMtsTests
        COMMENT "Rendering Midi Tuning Standard Tests"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderMtsTests PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/mts/"
    )
    add_render_job(renderMtsTests
        "${MTS_RENDER_DIR}/issue102_orig.${FEXT}"
        -R 0 -C 0 -g 2 -o synth.device-id=0 ${GENERAL_USER_GS2} issue102_orig/mts.mid
    )
    add_render_job(renderMtsTests
        "${MTS_RENDER_DIR}/issue102_marcus.${FEXT}"
        -R 0 -C 0 -g 3  ${GENERAL_USER_GS2} issue102_marcus/mts_marcus.mid
    )

    add_custom_target(renderSf2NRPN
        COMMENT "Rendering SF2 NRPN examples"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderSf2NRPN PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/sf2_nrpn"
    )
    add_render_job(renderSf2NRPN
        "${SF2_NRPN_RENDER_DIR}/issue1833.${FEXT}"
        -R 0 -C 0 -g 1 ${GENERAL_USER_GS2} issue1833/out.mid
    )

    add_custom_target(renderMisc
        COMMENT "Rendering misc. MIDIs"
        DEPENDS ${MANUAL_TEST_DEPENDS} create_out_dir
    )
    set_target_properties(renderMisc PROPERTIES
        WORKING_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}/manual/misc"
    )
    add_render_job(renderMisc
        "${MISC_RENDER_DIR}/crash-1-fpe.${FEXT}"
        -R 0 -C 0 -r 8000 -g 0.8 ${GENERAL_USER_GS2} crash-1-fpe.bin
    )
    add_render_job(renderMisc
        "${MISC_RENDER_DIR}/crash-2-segv.${FEXT}"
        -R 0 -C 0 -r 22050 -g 0.8 ${GENERAL_USER_GS2} crash-2-segv.bin
    )

    # Add a dependency so that rendering targets depends on check_rendering
    add_dependencies(check_rendering render1415)
    add_dependencies(check_rendering render1417)
    add_dependencies(check_rendering render1424)
    add_dependencies(check_rendering render1427)
    add_dependencies(check_rendering renderAltitude)
    add_dependencies(check_rendering renderFilter)
    add_dependencies(check_rendering renderUplift)
    add_dependencies(check_rendering renderChrisNRPN)
    add_dependencies(check_rendering renderHybridCol)
    add_dependencies(check_rendering renderPortamento)
    add_dependencies(check_rendering renderSfSpecTest)
    add_dependencies(check_rendering render1455)
    add_dependencies(check_rendering renderDK64JJU)
    add_dependencies(check_rendering renderExcl)
    add_dependencies(check_rendering rendere1m1)
    add_dependencies(check_rendering renderdspInterp)
    add_dependencies(check_rendering render1484)
    add_dependencies(check_manual renderRealtimeIIR)
    add_dependencies(check_rendering render1481)
    add_dependencies(check_rendering renderStreetwise)
    add_dependencies(check_rendering renderGeneralUserDemo)
    add_dependencies(check_rendering renderBankSelect)
    add_dependencies(check_rendering renderDMOD)
    add_dependencies(check_rendering renderRPN)
    add_dependencies(check_rendering renderSf2NRPN)
    # Rendering the reverbOverview would make the regression tests take way too long in CI!
    #add_dependencies(check_rendering renderReverbOverview)
    add_dependencies(check_rendering renderMtsTests)
    add_dependencies(check_rendering renderLimiterTests)
    add_dependencies(check_rendering render1505)
    add_dependencies(check_rendering renderGSDT1)
    add_dependencies(check_rendering renderMisc)

endif ( NOT CMAKE_GENERATOR MATCHES "Visual Studio" )
